const express = require('express');
const router = express.Router();
const Member = require('../models/Member');
const Book = require('../models/Book');

router.get('/:memberId', async (req, res) => {
  try {
    const member = await Member.findById(req.params.memberId).populate('cart.book');
    if (!member) return res.status(404).json({ message: 'Member not found' });
    
    let cartTotal = 0;
    const cartItems = member.cart.map(item => {
      const itemTotal = item.book.price * item.quantity;
      cartTotal += itemTotal;
      return { ...item.toObject(), itemTotal };
    });

    let discount = 0;
    if (member.membershipType === 'standard') discount = 0.05;
    if (member.membershipType === 'vip') discount = 0.10;
    
    const discountAmount = cartTotal * discount;
    const finalTotal = cartTotal - discountAmount;

    res.json({ cart: cartItems, subtotal: cartTotal, discount: discount * 100, discountAmount, total: finalTotal });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

router.post('/add', async (req, res) => {
  try {
    const { memberId, bookId, quantity = 1 } = req.body;
    const member = await Member.findById(memberId);
    const book = await Book.findById(bookId);

    if (!member) return res.status(404).json({ message: 'Member not found' });
    if (!book) return res.status(404).json({ message: 'Book not found' });
    if (book.stockQuantity < quantity) return res.status(400).json({ message: 'Insufficient stock' });

    const existingItem = member.cart.find(item => item.book.toString() === bookId);
    if (existingItem) {
      existingItem.quantity += quantity;
    } else {
      member.cart.push({ book: bookId, quantity, addedAt: new Date() });
    }

    await member.save();
    await member.populate('cart.book');
    res.json({ success: true, message: 'Added to cart', cart: member.cart });
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
});

router.delete('/remove/:memberId/:bookId', async (req, res) => {
  try {
    const member = await Member.findById(req.params.memberId);
    if (!member) return res.status(404).json({ message: 'Member not found' });
    member.cart = member.cart.filter(item => item.book.toString() !== req.params.bookId);
    await member.save();
    res.json({ success: true, message: 'Removed from cart' });
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
});

router.put('/update', async (req, res) => {
  try {
    const { memberId, bookId, quantity } = req.body;
    const member = await Member.findById(memberId);
    const book = await Book.findById(bookId);

    if (!member) return res.status(404).json({ message: 'Member not found' });
    if (!book) return res.status(404).json({ message: 'Book not found' });
    if (book.stockQuantity < quantity) return res.status(400).json({ message: 'Insufficient stock' });

    const cartItem = member.cart.find(item => item.book.toString() === bookId);
    if (cartItem) {
      cartItem.quantity = quantity;
      await member.save();
      await member.populate('cart.book');
      res.json({ success: true, cart: member.cart });
    } else {
      res.status(404).json({ message: 'Item not in cart' });
    }
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
});

router.post('/checkout', async (req, res) => {
  try {
    const { memberId } = req.body;
    const member = await Member.findById(memberId).populate('cart.book');
    
    if (!member) return res.status(404).json({ message: 'Member not found' });
    if (member.cart.length === 0) return res.status(400).json({ message: 'Cart is empty' });

    for (const item of member.cart) {
      if (item.book.stockQuantity < item.quantity) {
        return res.status(400).json({ message: `Insufficient stock for ${item.book.title}` });
      }
    }

    let total = 0;
    for (const item of member.cart) {
      const book = await Book.findById(item.book._id);
      book.stockQuantity -= item.quantity;
      await book.save();

      const itemPrice = item.book.price * item.quantity;
      total += itemPrice;

      member.purchasedBooks.push({ book: item.book._id, purchaseDate: new Date(), price: itemPrice });
    }

    let discount = 0;
    if (member.membershipType === 'standard') discount = 0.05;
    if (member.membershipType === 'vip') discount = 0.10;
    
    const discountAmount = total * discount;
    const finalTotal = total - discountAmount;

    member.cart = [];
    await member.save();

    res.json({ success: true, message: 'Purchase completed!', subtotal: total, discount: discount * 100, discountAmount, total: finalTotal });
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
});

module.exports = router;
