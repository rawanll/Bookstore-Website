const express = require('express');
const router = express.Router();
const Book = require('../models/Book');
const Member = require('../models/Member');

router.get('/', async (req, res) => {
  try {
    const books = await Book.find().populate('currentBorrowers.member', 'name memberId email');
    res.json(books);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

router.get('/:id', async (req, res) => {
  try {
    const book = await Book.findById(req.params.id)
      .populate('currentBorrowers.member', 'name memberId email phone');
    
    if (!book) {
      return res.status(404).json({ message: 'Book not found' });
    }
    
    res.json(book);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

router.post('/', async (req, res) => {
  try {
    const lastBook = await Book.findOne().sort({ bookId: -1 });
    let newBookId = 'BK001';
    
    if (lastBook && lastBook.bookId) {
      const lastNum = parseInt(lastBook.bookId.substring(2));
      newBookId = 'BK' + String(lastNum + 1).padStart(3, '0');
    }

    const book = new Book({
      bookId: newBookId,
      title: req.body.title,
      author: req.body.author,
      isbn: req.body.isbn,
      category: req.body.category,
      publisher: req.body.publisher || '',
      publishYear: req.body.publishYear,
      totalCopies: req.body.totalCopies || 1,
      availableCopies: req.body.totalCopies || 1,
      description: req.body.description || '',
      language: req.body.language || 'English',
      pages: req.body.pages || 0,
      shelfLocation: req.body.shelfLocation || ''
    });

    await book.save();
    res.status(201).json({ success: true, book });
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
});

router.put('/:id', async (req, res) => {
  try {
    const book = await Book.findById(req.params.id);
    if (!book) {
      return res.status(404).json({ message: 'Book not found' });
    }

    Object.keys(req.body).forEach(key => {
      if (key !== 'bookId' && key !== 'currentBorrowers') {
        book[key] = req.body[key];
      }
    });

    await book.save();
    res.json({ success: true, book });
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
});

router.delete('/:id', async (req, res) => {
  try {
    const book = await Book.findById(req.params.id);
    if (!book) {
      return res.status(404).json({ message: 'Book not found' });
    }

    if (book.currentBorrowers.length > 0) {
      return res.status(400).json({ message: 'Cannot delete book that is currently borrowed' });
    }
    
    await book.deleteOne();
    res.json({ success: true, message: 'Book deleted successfully' });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

router.post('/:id/borrow', async (req, res) => {
  try {
    const book = await Book.findById(req.params.id);
    const member = await Member.findById(req.body.memberId);

    if (!book) {
      return res.status(404).json({ message: 'Book not found' });
    }
    
    if (!member) {
      return res.status(404).json({ message: 'Member not found' });
    }

    if (book.availableCopies <= 0) {
      return res.status(400).json({ message: 'No copies available' });
    }

    const maxBooks = member.membershipType === 'vip' ? 10 : 
                     member.membershipType === 'premium' ? 5 : 3;

    if (member.borrowedBooks.length >= maxBooks) {
      return res.status(400).json({ 
        message: `You have reached your borrowing limit (${maxBooks} books)` 
      });
    }

    const borrowDate = new Date();
    const dueDate = new Date();
    dueDate.setDate(dueDate.getDate() + 14);

    book.availableCopies -= 1;
    book.currentBorrowers.push({
      member: member._id,
      borrowDate: borrowDate,
      dueDate: dueDate
    });

    member.borrowedBooks.push(book._id);
    member.borrowHistory.push({
      book: book._id,
      borrowDate: borrowDate,
      status: 'borrowed'
    });

    await book.save();
    await member.save();

    res.json({ 
      success: true, 
      message: 'Book borrowed successfully',
      dueDate: dueDate,
      book,
      member
    });
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
});

router.post('/:id/return', async (req, res) => {
  try {
    const book = await Book.findById(req.params.id);
    const member = await Member.findById(req.body.memberId);

    if (!book) {
      return res.status(404).json({ message: 'Book not found' });
    }
    
    if (!member) {
      return res.status(404).json({ message: 'Member not found' });
    }

    const borrowerIndex = book.currentBorrowers.findIndex(
      b => b.member.toString() === member._id.toString()
    );

    if (borrowerIndex === -1) {
      return res.status(400).json({ message: 'You have not borrowed this book' });
    }

    book.availableCopies += 1;
    book.currentBorrowers.splice(borrowerIndex, 1);

    member.borrowedBooks = member.borrowedBooks.filter(
      bookId => bookId.toString() !== book._id.toString()
    );

    const historyIndex = member.borrowHistory.findIndex(
      h => h.book.toString() === book._id.toString() && h.status === 'borrowed'
    );
    
    if (historyIndex !== -1) {
      member.borrowHistory[historyIndex].returnDate = new Date();
      member.borrowHistory[historyIndex].status = 'returned';
    }

    await book.save();
    await member.save();

    res.json({ 
      success: true, 
      message: 'Book returned successfully',
      book,
      member
    });
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
});

module.exports = router;
