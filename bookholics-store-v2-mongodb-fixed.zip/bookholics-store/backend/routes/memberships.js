const express = require('express');
const router = express.Router();
const Membership = require('../models/Membership');

router.get('/', async (req, res) => {
  try {
    const memberships = await Membership.find();
    res.json(memberships);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

router.post('/seed', async (req, res) => {
  try {
    await Membership.deleteMany({});
    
    const plans = [
      {
        name: 'Basic Membership',
        type: 'basic',
        duration: 365,
        maxBooks: 3,
        price: 0,
        benefits: [
          'Borrow up to 3 books at a time',
          '14 days borrowing period',
          'Access to basic collection'
        ]
      },
      {
        name: 'Premium Membership',
        type: 'premium',
        duration: 365,
        maxBooks: 5,
        price: 50,
        benefits: [
          'Borrow up to 5 books at a time',
          '21 days borrowing period',
          'Access to premium collection',
          'Priority reservations',
          'Extended borrowing on request'
        ]
      },
      {
        name: 'VIP Membership',
        type: 'vip',
        duration: 365,
        maxBooks: 10,
        price: 100,
        benefits: [
          'Borrow up to 10 books at a time',
          '30 days borrowing period',
          'Access to all collections',
          'Priority reservations',
          'Extended borrowing on request',
          'Free delivery service',
          'Exclusive events access'
        ]
      }
    ];

    await Membership.insertMany(plans);
    res.json({ success: true, message: 'Membership plans created' });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

module.exports = router;
