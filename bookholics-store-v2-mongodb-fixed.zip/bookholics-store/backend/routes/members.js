const express = require('express');
const router = express.Router();
const jwt = require('jsonwebtoken');
const Member = require('../models/Member');

router.post('/register', async (req, res) => {
  try {
    const existingMember = await Member.findOne({ email: req.body.email });
    if (existingMember) {
      return res.status(400).json({ message: 'Email already registered' });
    }

    const lastMember = await Member.findOne().sort({ memberId: -1 });
    let newMemberId = 'MEM001';
    if (lastMember && lastMember.memberId) {
      const lastNum = parseInt(lastMember.memberId.substring(3));
      newMemberId = 'MEM' + String(lastNum + 1).padStart(3, '0');
    }

    const member = new Member({
      memberId: newMemberId,
      name: req.body.name,
      email: req.body.email,
      password: req.body.password,
      phone: req.body.phone,
      address: req.body.address || ''
    });

    await member.save();
    const token = jwt.sign({ id: member._id }, process.env.JWT_SECRET, { expiresIn: '30d' });
    
    res.status(201).json({ 
      success: true,
      token,
      member: {
        id: member._id,
        memberId: member.memberId,
        name: member.name,
        email: member.email,
        phone: member.phone,
        membershipType: member.membershipType,
        membershipExpiry: member.membershipExpiry
      }
    });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

router.post('/login', async (req, res) => {
  try {
    const member = await Member.findOne({ email: req.body.email });
    if (!member) {
      return res.status(401).json({ message: 'Invalid email or password' });
    }

    const isMatch = await member.comparePassword(req.body.password);
    if (!isMatch) {
      return res.status(401).json({ message: 'Invalid email or password' });
    }

    const token = jwt.sign({ id: member._id }, process.env.JWT_SECRET, { expiresIn: '30d' });
    
    res.json({ 
      success: true,
      token,
      member: {
        id: member._id,
        memberId: member.memberId,
        name: member.name,
        email: member.email,
        phone: member.phone,
        membershipType: member.membershipType,
        membershipExpiry: member.membershipExpiry
      }
    });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

router.get('/:id', async (req, res) => {
  try {
    const member = await Member.findById(req.params.id)
      .select('-password')
      .populate('borrowedBooks');
    
    if (!member) {
      return res.status(404).json({ message: 'Member not found' });
    }
    
    res.json(member);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

router.get('/', async (req, res) => {
  try {
    const members = await Member.find()
      .select('-password')
      .populate('borrowedBooks');
    res.json(members);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

router.put('/:id/membership', async (req, res) => {
  try {
    const member = await Member.findById(req.params.id);
    if (!member) {
      return res.status(404).json({ message: 'Member not found' });
    }

    member.membershipType = req.body.membershipType;
    member.membershipExpiry = new Date(Date.now() + (req.body.duration * 24 * 60 * 60 * 1000));
    
    await member.save();
    res.json({ success: true, member });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

module.exports = router;
