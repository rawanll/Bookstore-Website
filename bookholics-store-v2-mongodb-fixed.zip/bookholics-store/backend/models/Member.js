const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');

const memberSchema = new mongoose.Schema({
  memberId: { type: String, required: true, unique: true },
  name: { type: String, required: true },
  email: { type: String, required: true, unique: true },
  password: { type: String, required: true },
  phone: { type: String, required: true },
  address: { type: String, default: '' },
  membershipType: { type: String, enum: ['guest', 'standard', 'vip'], default: 'guest' },
  membershipExpiry: { type: Date, default: null },
  isActive: { type: Boolean, default: true },
  cart: [{
    book: { type: mongoose.Schema.Types.ObjectId, ref: 'Book' },
    quantity: { type: Number, default: 1 },
    addedAt: { type: Date, default: Date.now }
  }],
  borrowedBooks: [{ type: mongoose.Schema.Types.ObjectId, ref: 'Book' }],
  purchasedBooks: [{
    book: { type: mongoose.Schema.Types.ObjectId, ref: 'Book' },
    purchaseDate: { type: Date, default: Date.now },
    price: Number
  }],
  borrowHistory: [{
    book: { type: mongoose.Schema.Types.ObjectId, ref: 'Book' },
    borrowDate: Date,
    returnDate: Date,
    status: String
  }]
}, { timestamps: true });

memberSchema.pre('save', async function(next) {
  if (!this.isModified('password')) return next();
  this.password = await bcrypt.hash(this.password, 10);
  next();
});

memberSchema.methods.comparePassword = async function(candidatePassword) {
  return await bcrypt.compare(candidatePassword, this.password);
};

module.exports = mongoose.model('Member', memberSchema);
