const mongoose = require('mongoose');

const bookSchema = new mongoose.Schema({
  bookId: { type: String, required: true, unique: true },
  title: { type: String, required: true },
  author: { type: String, required: true },
  isbn: { type: String, required: true, unique: true },
  category: { type: String, required: true },
  publisher: { type: String, default: '' },
  publishYear: { type: Number, required: true },
  price: { type: Number, required: true, default: 20 },
  stockQuantity: { type: Number, required: true, default: 5 },
  totalCopies: { type: Number, required: true, default: 1 },
  availableCopies: { type: Number, required: true, default: 1 },
  description: { type: String, default: '' },
  language: { type: String, default: 'English' },
  pages: { type: Number, default: 0 },
  shelfLocation: { type: String, default: '' },
  currentBorrowers: [{
    member: { type: mongoose.Schema.Types.ObjectId, ref: 'Member' },
    borrowDate: Date,
    dueDate: Date
  }]
}, { timestamps: true });

module.exports = mongoose.model('Book', bookSchema);
