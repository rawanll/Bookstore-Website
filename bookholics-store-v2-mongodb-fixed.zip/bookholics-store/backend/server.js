const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
require('dotenv').config();

const app = express();

// CORS configuration
const corsOptions = {
  origin: process.env.FRONTEND_URL || 'http://localhost:3000',
  credentials: true,
  optionsSuccessStatus: 200
};
app.use(cors(corsOptions));
app.use(express.json());

// MongoDB connection with better error handling
const connectDB = async () => {
  try {
    await mongoose.connect(process.env.MONGODB_URI, {
      useNewUrlParser: true,
      useUnifiedTopology: true,
    });
    console.log('✓ MongoDB connected successfully');
    console.log('✓ Database:', mongoose.connection.name);
  } catch (err) {
    console.error('✗ MongoDB connection error:', err.message);
    console.error('Make sure MongoDB is running on localhost:27017');
    process.exit(1);
  }
};

// Connect to MongoDB
connectDB();

// Handle MongoDB connection errors after initial connection
mongoose.connection.on('error', (err) => {
  console.error('MongoDB connection error:', err);
});

mongoose.connection.on('disconnected', () => {
  console.log('MongoDB disconnected');
});

app.use('/api/members', require('./routes/members'));
app.use('/api/books', require('./routes/books'));
app.use('/api/memberships', require('./routes/memberships'));
app.use('/api/cart', require('./routes/cart'));

app.get('/api/test', (req, res) => res.json({ message: 'Bookholics Store 2 API working!' }));

// Health check endpoint
app.get('/api/health', (req, res) => {
  const health = {
    status: 'OK',
    mongodb: mongoose.connection.readyState === 1 ? 'Connected' : 'Disconnected',
    database: mongoose.connection.name || 'Not connected',
    timestamp: new Date().toISOString()
  };
  res.json(health);
});

const PORT = process.env.PORT || 5000;
app.listen(PORT, () => console.log(`✓ Server running on port ${PORT}`));
