#!/bin/bash

echo "========================================"
echo "Bookholics Store 2 - Backend Startup"
echo "========================================"
echo ""

echo "Testing MongoDB Connection..."
node test-connection.js

if [ $? -ne 0 ]; then
    echo ""
    echo "========================================"
    echo "ERROR: MongoDB connection failed!"
    echo "========================================"
    echo ""
    echo "Please:"
    echo "1. Make sure MongoDB is running"
    echo "2. Check the .env file"
    echo "3. See MONGODB-TROUBLESHOOTING.md for help"
    echo ""
    exit 1
fi

echo ""
echo "========================================"
echo "MongoDB connection successful!"
echo "Starting backend server..."
echo "========================================"
echo ""

node server.js
