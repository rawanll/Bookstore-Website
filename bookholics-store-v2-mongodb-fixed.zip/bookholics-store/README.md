# Bookholics Store 2 🚀

A full-stack library management system with membership tiers, book borrowing, and shopping features.

## 🔧 FIXES APPLIED

### Proxy Issue Resolution
The application was crashing due to proxy configuration issues. Here's what was fixed:

1. **Removed problematic proxy** from `frontend/package.json`
2. **Created API configuration** file (`frontend/src/config/api.js`)
3. **Updated all axios calls** to use full URLs with `API_BASE_URL`
4. **Added CORS configuration** to backend server
5. **Created .env files** for environment-specific configuration

### Changes Made
- ✅ Removed `"proxy": "http://localhost:5000"` from package.json
- ✅ Added centralized API configuration
- ✅ Updated all API calls in Login, Register, Books, AddBook, MyAccount, Memberships, and ShoppingCart
- ✅ Changed branding to "Bookholics Store 2"
- ✅ Improved CORS handling in backend

## 🚀 Quick Start

### Prerequisites
- Node.js (v14 or higher)
- MongoDB (local or cloud)
- npm or yarn

### Backend Setup

1. Navigate to backend directory:
```bash
cd backend
```

2. Install dependencies:
```bash
npm install
```

3. Create `.env` file in backend directory:
```env
MONGODB_URI=mongodb://localhost:27017/bookholics-store
PORT=5000
FRONTEND_URL=http://localhost:3000
```

4. Start the backend server:
```bash
node server.js
```

The backend will run on `http://localhost:5000`

### Frontend Setup

1. Navigate to frontend directory:
```bash
cd frontend
```

2. Install dependencies:
```bash
npm install
```

3. The `.env` file is already created with:
```env
REACT_APP_API_URL=http://localhost:5000
```

4. Start the frontend:
```bash
npm start
```

The frontend will run on `http://localhost:3000`

## 🌐 Deployment Configuration

### For Production Deployment:

1. **Backend**: Update your `.env` file:
```env
MONGODB_URI=your_production_mongodb_uri
PORT=5000
FRONTEND_URL=https://your-frontend-domain.com
```

2. **Frontend**: Update `.env` file:
```env
REACT_APP_API_URL=https://your-backend-domain.com
```

## 📝 Features

- **Member Management**: Register, login, and manage accounts
- **Membership Tiers**: Guest, Standard, and VIP with different benefits
- **Book Management**: Browse, borrow, and purchase books
- **Shopping Cart**: Add books to cart with membership discounts
- **Admin Functions**: Add/delete books (for admin users)

## 🎯 Membership Benefits

### Guest (Free)
- Borrow up to 3 books
- 14 days borrowing period
- ❌ Cannot buy books

### Standard ($30/year)
- Borrow up to 5 books
- 30 days borrowing period
- ✅ Buy books with 5% discount
- ✅ Shopping cart access

### VIP ($100/year)
- Borrow up to 10 books
- ✅ 10% discount on purchases
- ✅ FREE delivery
- ✅ Priority support

## 🛠️ Technology Stack

### Frontend
- React 18
- React Router DOM
- Axios
- CSS3

### Backend
- Node.js
- Express.js
- MongoDB with Mongoose
- CORS
- dotenv

## 📂 Project Structure

```
bookholics-store/
├── backend/
│   ├── models/          # MongoDB models
│   ├── routes/          # API routes
│   ├── server.js        # Express server
│   ├── package.json
│   └── .env
├── frontend/
│   ├── public/
│   ├── src/
│   │   ├── config/      # API configuration
│   │   ├── pages/       # React pages
│   │   ├── App.js
│   │   ├── App.css
│   │   └── index.js
│   ├── package.json
│   └── .env
└── README.md
```

## 🐛 Troubleshooting

### If you get CORS errors:
1. Make sure backend is running on port 5000
2. Check that `FRONTEND_URL` in backend `.env` matches your frontend URL
3. Verify `REACT_APP_API_URL` in frontend `.env` matches your backend URL

### If API calls fail:
1. Ensure backend server is running
2. Check browser console for error messages
3. Verify MongoDB is connected
4. Check that all environment variables are set correctly

### If pages are blank:
1. Clear browser cache
2. Delete `node_modules` and `package-lock.json` in frontend
3. Run `npm install` again
4. Restart the development server

## 🔐 Default Admin Access

To create an admin account, register normally and then manually update the database:
1. Find your member in MongoDB
2. Change `memberId` to start with 'ADM' (e.g., 'ADM001')

## 📞 Support

For issues or questions, please check:
1. Console logs in browser developer tools
2. Backend terminal output
3. MongoDB connection status

## 🎉 Version 2 Updates

- Fixed proxy configuration issues
- Improved API handling with centralized configuration
- Better CORS support
- Updated branding to "Bookholics Store 2"
- Enhanced error handling

---

**Note**: This is Version 2 with improved stability and fixed proxy issues!
