#!/bin/bash

echo "🚀 Bookholics Store 2 - Quick Setup Script"
echo "=========================================="
echo ""

# Check if Node.js is installed
if ! command -v node &> /dev/null; then
    echo "❌ Node.js is not installed. Please install Node.js first."
    exit 1
fi

echo "✅ Node.js version: $(node --version)"
echo ""

# Backend Setup
echo "📦 Setting up Backend..."
cd backend
if [ ! -f ".env" ]; then
    echo "⚠️  Creating backend .env file..."
    cat > .env << EOF
MONGODB_URI=mongodb://localhost:27017/bookholics-store
PORT=5000
FRONTEND_URL=http://localhost:3000
EOF
    echo "✅ Backend .env file created"
else
    echo "✅ Backend .env file already exists"
fi

echo "📦 Installing backend dependencies..."
npm install
if [ $? -ne 0 ]; then
    echo "❌ Backend installation failed"
    exit 1
fi
echo "✅ Backend dependencies installed"
cd ..

# Frontend Setup
echo ""
echo "📦 Setting up Frontend..."
cd frontend
if [ ! -f ".env" ]; then
    echo "⚠️  Creating frontend .env file..."
    cat > .env << EOF
REACT_APP_API_URL=http://localhost:5000
EOF
    echo "✅ Frontend .env file created"
else
    echo "✅ Frontend .env file already exists"
fi

echo "📦 Installing frontend dependencies..."
npm install
if [ $? -ne 0 ]; then
    echo "❌ Frontend installation failed"
    exit 1
fi
echo "✅ Frontend dependencies installed"
cd ..

echo ""
echo "=========================================="
echo "✅ Setup Complete!"
echo "=========================================="
echo ""
echo "📝 Next Steps:"
echo "1. Make sure MongoDB is running"
echo "2. Open two terminal windows:"
echo ""
echo "   Terminal 1 (Backend):"
echo "   cd backend && node server.js"
echo ""
echo "   Terminal 2 (Frontend):"
echo "   cd frontend && npm start"
echo ""
echo "3. Access the app at http://localhost:3000"
echo ""
echo "🎉 Welcome to Bookholics Store 2!"
