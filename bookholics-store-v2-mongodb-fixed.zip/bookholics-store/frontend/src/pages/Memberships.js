import React, { useState } from 'react';
import axios from 'axios';
import API_BASE_URL from '../config/api';

function Memberships({ member, setMember }) {
  const [message, setMessage] = useState({ type: '', text: '' });

  const showMessage = (type, text) => {
    setMessage({ type, text });
    setTimeout(() => setMessage({ type: '', text: '' }), 4000);
  };

  const handleUpgrade = async (membershipType, price, duration) => {
    if (window.confirm(`Upgrade to ${membershipType} membership for $${price}?`)) {
      try {
        await axios.put(`${API_BASE_URL}/api/members/${member.id}/membership`, { membershipType, duration });
        const updatedMember = { ...member, membershipType };
        setMember(updatedMember);
        localStorage.setItem('member', JSON.stringify(updatedMember));
        showMessage('success', `Successfully upgraded to ${membershipType}!`);
      } catch (error) {
        showMessage('error', 'Failed to upgrade');
      }
    }
  };

  return (
    <div className="container">
      <div className="books-container">
        <h2 style={{ marginBottom: '1rem', textAlign: 'center' }}>Membership Plans</h2>
        <p style={{ textAlign: 'center', color: '#718096', marginBottom: '3rem' }}>Choose the plan that fits your needs</p>

        {message.text && <div className={`alert alert-${message.type}`}>{message.text}</div>}

        <div className="membership-grid">
          <div className="membership-card">
            <h3 className="membership-name">Guest</h3>
            <div className="membership-price">$0<span style={{fontSize:'1rem'}}>/year</span></div>
            <div className="membership-benefits">
              <h4>Features:</h4>
              <ul>
                <li>Borrow up to 3 books</li>
                <li>14 days period</li>
              </ul>
              <h4 style={{color:'#e74c3c'}}>Limitations:</h4>
              <ul>
                <li>❌ Cannot buy books</li>
                <li>❌ No cart</li>
              </ul>
            </div>
            {member.membershipType === 'guest' ? (
              <button className="btn-upgrade" disabled style={{opacity:0.5}}>Current Plan</button>
            ) : (
              <button className="btn-upgrade" disabled style={{opacity:0.5}}>Default</button>
            )}
          </div>

          <div className="membership-card featured">
            <h3 className="membership-name">⭐ Standard</h3>
            <div className="membership-price">$30<span style={{fontSize:'1rem'}}>/year</span></div>
            <div className="membership-benefits">
              <h4>Everything in Guest PLUS:</h4>
              <ul>
                <li>✅ Buy books</li>
                <li>✅ Shopping cart</li>
                <li>✅ 5% discount</li>
                <li>✅ Borrow 5 books</li>
                <li>✅ 30 days period</li>
              </ul>
            </div>
            {member.membershipType === 'standard' ? (
              <button className="btn-upgrade" disabled style={{opacity:0.5}}>Current Plan ✓</button>
            ) : (
              <button className="btn-upgrade" onClick={() => handleUpgrade('standard', 30, 365)}>Subscribe - $30/year</button>
            )}
          </div>

          <div className="membership-card featured">
            <h3 className="membership-name">👑 VIP</h3>
            <div className="membership-price">$100<span style={{fontSize:'1rem'}}>/year</span></div>
            <div className="membership-benefits">
              <h4>Everything in Standard PLUS:</h4>
              <ul>
                <li>✅ 10% discount</li>
                <li>✅ Borrow 10 books</li>
                <li>✅ FREE delivery</li>
                <li>✅ Priority support</li>
              </ul>
            </div>
            {member.membershipType === 'vip' ? (
              <button className="btn-upgrade" disabled style={{opacity:0.5}}>Current Plan ✓</button>
            ) : (
              <button className="btn-upgrade" onClick={() => handleUpgrade('vip', 100, 365)}>Subscribe - $100/year</button>
            )}
          </div>
        </div>

        <div style={{marginTop:'2rem',padding:'1.5rem',background:'rgba(52,152,219,0.1)',borderRadius:'10px',textAlign:'center'}}>
          <h3 style={{color:'#3498db'}}>Your Current Plan: {member.membershipType.toUpperCase()}</h3>
        </div>
      </div>
    </div>
  );
}

export default Memberships;
