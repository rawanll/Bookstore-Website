import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';
import API_BASE_URL from '../config/api';

function ShoppingCart({ member }) {
  const navigate = useNavigate();
  const [cartData, setCartData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [message, setMessage] = useState({ type: '', text: '' });

  useEffect(() => {
    fetchCart();
  }, []);

  const fetchCart = async () => {
    try {
      const response = await axios.get(`${API_BASE_URL}/api/cart/${member.id}`);
      setCartData(response.data);
      setLoading(false);
    } catch (error) {
      setLoading(false);
    }
  };

  const showMessage = (type, text) => {
    setMessage({ type, text });
    setTimeout(() => setMessage({ type: '', text: '' }), 4000);
  };

  const updateQuantity = async (bookId, quantity) => {
    if (quantity < 1) return;
    try {
      await axios.put(`${API_BASE_URL}/api/cart/update`, { memberId: member.id, bookId, quantity });
      fetchCart();
    } catch (error) {
      showMessage('error', 'Failed to update');
    }
  };

  const removeItem = async (bookId) => {
    try {
      await axios.delete(`${API_BASE_URL}/api/cart/remove/${member.id}/${bookId}`);
      showMessage('success', 'Removed from cart');
      fetchCart();
    } catch (error) {
      showMessage('error', 'Failed to remove');
    }
  };

  const handleCheckout = async () => {
    if (window.confirm('Complete purchase?')) {
      try {
        await axios.post(`${API_BASE_URL}/api/cart/checkout`, { memberId: member.id });
        showMessage('success', 'Purchase completed!');
        setTimeout(() => navigate('/account'), 2000);
      } catch (error) {
        showMessage('error', 'Checkout failed');
      }
    }
  };

  if (loading) {
    return (
      <div className="container">
        <div className="books-container">
          <p style={{textAlign:'center',padding:'3rem'}}>Loading cart...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="container">
      <div className="books-container">
        <h2 style={{marginBottom:'2rem'}}>🛒 Shopping Cart</h2>
        
        {message.text && <div className={`alert alert-${message.type}`}>{message.text}</div>}

        {cartData && cartData.cart.length > 0 ? (
          <>
            <div className="book-grid">
              {cartData.cart.map(item => (
                <div key={item.book._id} className="book-card">
                  <h3 className="book-title">{item.book.title}</h3>
                  <p className="book-author">by {item.book.author}</p>
                  <p><strong>Price:</strong> ${item.book.price}</p>
                  <p><strong>Quantity:</strong> {item.quantity}</p>
                  <p><strong>Total:</strong> ${item.itemTotal.toFixed(2)}</p>
                  <div className="book-actions">
                    <button onClick={() => updateQuantity(item.book._id, item.quantity - 1)}>−</button>
                    <span>{item.quantity}</span>
                    <button onClick={() => updateQuantity(item.book._id, item.quantity + 1)}>+</button>
                    <button className="btn-delete" onClick={() => removeItem(item.book._id)}>Remove</button>
                  </div>
                </div>
              ))}
            </div>

            <div style={{background:'white',padding:'2rem',borderRadius:'15px',marginTop:'2rem',maxWidth:'400px',marginLeft:'auto'}}>
              <h3>Order Summary</h3>
              <div style={{display:'flex',justifyContent:'space-between',padding:'0.5rem 0'}}>
                <span>Subtotal:</span>
                <span>${cartData.subtotal.toFixed(2)}</span>
              </div>
              {cartData.discount > 0 && (
                <div style={{display:'flex',justifyContent:'space-between',padding:'0.5rem 0',color:'#27ae60'}}>
                  <span>Discount ({cartData.discount}%):</span>
                  <span>-${cartData.discountAmount.toFixed(2)}</span>
                </div>
              )}
              <div style={{display:'flex',justifyContent:'space-between',padding:'1rem 0',borderTop:'2px solid #ddd',fontWeight:'bold'}}>
                <span>Total:</span>
                <span>${cartData.total.toFixed(2)}</span>
              </div>
              <button className="btn-submit" onClick={handleCheckout}>Complete Purchase</button>
            </div>
          </>
        ) : (
          <div style={{textAlign:'center',padding:'3rem'}}>
            <h3>Your cart is empty</h3>
            <button className="btn-primary" onClick={() => navigate('/books')} style={{marginTop:'1rem'}}>Browse Books</button>
          </div>
        )}
      </div>
    </div>
  );
}

export default ShoppingCart;
