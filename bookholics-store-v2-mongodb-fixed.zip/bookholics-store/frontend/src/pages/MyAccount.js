import React, { useState, useEffect } from 'react';
import axios from 'axios';
import API_BASE_URL from '../config/api';

function MyAccount({ member, setMember }) {
  const [memberData, setMemberData] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchMemberData();
  }, []);

  const fetchMemberData = async () => {
    try {
      const response = await axios.get(`${API_BASE_URL}/api/members/${member.id}`);
      setMemberData(response.data);
      setLoading(false);
    } catch (error) {
      console.error('Error fetching member data:', error);
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="container">
        <div className="account-container">
          <p style={{ textAlign: 'center', padding: '3rem', color: '#718096' }}>Loading your account...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="container">
      <div className="account-container">
        <div className="account-header">
          <h2>My Account</h2>
          <p style={{ fontSize: '1.5rem', marginTop: '1rem' }}>{memberData.name}</p>
          <p style={{ opacity: 0.9 }}>{memberData.memberId}</p>
        </div>

        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(250px, 1fr))', gap: '1.5rem', marginBottom: '2rem' }}>
          <div className="card">
            <h4 style={{ marginBottom: '0.5rem', color: '#4a5568' }}>Email</h4>
            <p style={{ color: '#2d3748', fontWeight: '500' }}>{memberData.email}</p>
          </div>
          <div className="card">
            <h4 style={{ marginBottom: '0.5rem', color: '#4a5568' }}>Phone</h4>
            <p style={{ color: '#2d3748', fontWeight: '500' }}>{memberData.phone}</p>
          </div>
          <div className="card">
            <h4 style={{ marginBottom: '0.5rem', color: '#4a5568' }}>Membership Type</h4>
            <p style={{ color: '#2d3748', fontWeight: '500', textTransform: 'capitalize' }}>{memberData.membershipType}</p>
          </div>
          <div className="card">
            <h4 style={{ marginBottom: '0.5rem', color: '#4a5568' }}>Borrowed Books</h4>
            <p style={{ color: '#2d3748', fontWeight: '500', fontSize: '1.5rem' }}>{memberData.borrowedBooks.length}</p>
          </div>
        </div>

        <div className="borrowed-books">
          <h3>Currently Borrowed Books</h3>
          
          {memberData.borrowedBooks && memberData.borrowedBooks.length > 0 ? (
            <div className="book-grid">
              {memberData.borrowedBooks.map(book => {
                const borrowInfo = book.currentBorrowers.find(b => b.member === member.id);
                return (
                  <div key={book._id} className="book-card">
                    <span className="book-id">{book.bookId}</span>
                    <h3 className="book-title">{book.title}</h3>
                    <p className="book-author">by {book.author}</p>
                    <div className="book-details">
                      <p><strong>Category:</strong> {book.category}</p>
                      {borrowInfo && (
                        <>
                          <p><strong>Borrowed:</strong> {new Date(borrowInfo.borrowDate).toLocaleDateString()}</p>
                          <p><strong>Due:</strong> {new Date(borrowInfo.dueDate).toLocaleDateString()}</p>
                        </>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          ) : (
            <p style={{ textAlign: 'center', padding: '2rem', color: '#718096' }}>
              You haven't borrowed any books yet. Visit the Books page to browse available books.
            </p>
          )}
        </div>
      </div>
    </div>
  );
}

export default MyAccount;
