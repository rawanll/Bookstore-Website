import React, { useState } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';
import API_BASE_URL from '../config/api';

function AddBook() {
  const navigate = useNavigate();
  const [formData, setFormData] = useState({
    title: '',
    author: '',
    isbn: '',
    category: '',
    publisher: '',
    publishYear: '',
    totalCopies: '1',
    description: '',
    language: 'English',
    pages: '',
    shelfLocation: ''
  });
  const [message, setMessage] = useState({ type: '', text: '' });
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);

    try {
      await axios.post(`${API_BASE_URL}/api/books`, formData);
      setMessage({ type: 'success', text: 'Book added successfully!' });
      setTimeout(() => navigate('/books'), 2000);
    } catch (error) {
      setMessage({ type: 'error', text: error.response?.data?.message || 'Failed to add book' });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="container">
      <div className="form-container">
        <h2>Add New Book</h2>
        
        {message.text && (
          <div className={`alert alert-${message.type}`}>{message.text}</div>
        )}

        <form onSubmit={handleSubmit}>
          <div className="form-group">
            <label>Book Title *</label>
            <input
              type="text"
              value={formData.title}
              onChange={(e) => setFormData({...formData, title: e.target.value})}
              required
            />
          </div>

          <div className="form-group">
            <label>Author *</label>
            <input
              type="text"
              value={formData.author}
              onChange={(e) => setFormData({...formData, author: e.target.value})}
              required
            />
          </div>

          <div className="form-group">
            <label>ISBN *</label>
            <input
              type="text"
              value={formData.isbn}
              onChange={(e) => setFormData({...formData, isbn: e.target.value})}
              required
            />
          </div>

          <div className="form-group">
            <label>Category *</label>
            <input
              type="text"
              placeholder="Fiction, Science, History, etc."
              value={formData.category}
              onChange={(e) => setFormData({...formData, category: e.target.value})}
              required
            />
          </div>

          <div className="form-group">
            <label>Publisher</label>
            <input
              type="text"
              value={formData.publisher}
              onChange={(e) => setFormData({...formData, publisher: e.target.value})}
            />
          </div>

          <div className="form-group">
            <label>Publish Year *</label>
            <input
              type="number"
              value={formData.publishYear}
              onChange={(e) => setFormData({...formData, publishYear: e.target.value})}
              required
            />
          </div>

          <div className="form-group">
            <label>Total Copies *</label>
            <input
              type="number"
              min="1"
              value={formData.totalCopies}
              onChange={(e) => setFormData({...formData, totalCopies: e.target.value})}
              required
            />
          </div>

          <div className="form-group">
            <label>Language</label>
            <input
              type="text"
              value={formData.language}
              onChange={(e) => setFormData({...formData, language: e.target.value})}
            />
          </div>

          <div className="form-group">
            <label>Number of Pages</label>
            <input
              type="number"
              value={formData.pages}
              onChange={(e) => setFormData({...formData, pages: e.target.value})}
            />
          </div>

          <div className="form-group">
            <label>Shelf Location</label>
            <input
              type="text"
              placeholder="e.g., A-12, B-05"
              value={formData.shelfLocation}
              onChange={(e) => setFormData({...formData, shelfLocation: e.target.value})}
            />
          </div>

          <div className="form-group">
            <label>Description</label>
            <textarea
              value={formData.description}
              onChange={(e) => setFormData({...formData, description: e.target.value})}
              placeholder="Brief description of the book..."
            />
          </div>

          <button type="submit" className="btn-submit" disabled={loading}>
            {loading ? 'Adding Book...' : 'Add Book'}
          </button>
        </form>
      </div>
    </div>
  );
}

export default AddBook;
