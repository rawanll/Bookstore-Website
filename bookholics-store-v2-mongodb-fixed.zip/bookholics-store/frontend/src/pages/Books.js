import React, { useState, useEffect } from 'react';
import axios from 'axios';
import API_BASE_URL from '../config/api';

function Books({ member }) {
  const [books, setBooks] = useState([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [message, setMessage] = useState({ type: '', text: '' });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchBooks();
  }, []);

  const fetchBooks = async () => {
    try {
      const response = await axios.get(`${API_BASE_URL}/api/books`);
      setBooks(response.data);
      setLoading(false);
    } catch (error) {
      setLoading(false);
    }
  };

  const showMessage = (type, text) => {
    setMessage({ type, text });
    setTimeout(() => setMessage({ type: '', text: '' }), 4000);
  };

  const handleAddToCart = async (bookId) => {
    if (member.membershipType === 'guest') {
      showMessage('error', 'Upgrade to Standard or VIP to buy books!');
      return;
    }
    try {
      await axios.post(`${API_BASE_URL}/api/cart/add`, { memberId: member.id, bookId, quantity: 1 });
      showMessage('success', '✓ Added to cart!');
    } catch (error) {
      showMessage('error', 'Failed to add to cart');
    }
  };

  const handleBorrow = async (bookId) => {
    try {
      await axios.post(`${API_BASE_URL}/api/books/${bookId}/borrow`, { memberId: member.id });
      showMessage('success', 'Book borrowed! Remember 2-3 day minimum.');
      fetchBooks();
    } catch (error) {
      showMessage('error', error.response?.data?.message || 'Failed to borrow');
    }
  };

  const handleReturn = async (bookId) => {
    try {
      await axios.post(`${API_BASE_URL}/api/books/${bookId}/return`, { memberId: member.id });
      showMessage('success', 'Book returned!');
      fetchBooks();
    } catch (error) {
      showMessage('error', error.response?.data?.message || 'Cannot return yet');
    }
  };

  const handleDelete = async (bookId) => {
    if (window.confirm('Delete this book?')) {
      try {
        await axios.delete(`${API_BASE_URL}/api/books/${bookId}`);
        showMessage('success', 'Book deleted');
        fetchBooks();
      } catch (error) {
        showMessage('error', 'Failed to delete');
      }
    }
  };

  const filteredBooks = books.filter(book =>
    book.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
    book.author.toLowerCase().includes(searchTerm.toLowerCase()) ||
    book.bookId.toLowerCase().includes(searchTerm.toLowerCase()) ||
    book.category.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const isBorrowedByMe = (book) => {
    return book.currentBorrowers.some(b => b.member._id === member.id);
  };

  return (
    <div className="container">
      <div className="books-container">
        <h2 style={{marginBottom:'2rem'}}>Browse Books</h2>
        
        {message.text && <div className={`alert alert-${message.type}`}>{message.text}</div>}

        <div className="search-section">
          <input
            type="text"
            placeholder="Search by title, author, book ID, or category..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="search-bar"
          />
        </div>

        {loading ? (
          <p style={{textAlign:'center',padding:'3rem'}}>Loading...</p>
        ) : (
          <div className="book-grid">
            {filteredBooks.map(book => (
              <div key={book._id} className="book-card">
                <span className="book-id">{book.bookId}</span>
                <h3 className="book-title">{book.title}</h3>
                <p className="book-author">by {book.author}</p>
                
                <div className="book-details">
                  <p><strong>Category:</strong> {book.category}</p>
                  <p><strong>Published:</strong> {book.publishYear}</p>
                  <p><strong>💰 Price:</strong> ${book.price || 20}</p>
                  <p><strong>📦 Stock:</strong> {book.stockQuantity || 5}</p>
                  <p><strong>📚 Borrow:</strong> {book.availableCopies} of {book.totalCopies}</p>
                </div>

                <span className={`availability-badge ${book.availableCopies > 0 ? 'available' : 'not-available'}`}>
                  {book.availableCopies > 0 ? '✓ Available' : '✗ Not Available'}
                </span>

                <div className="book-actions">
                  {member.membershipType !== 'guest' && (
                    <button className="btn-buy" onClick={() => handleAddToCart(book._id)}>
                      🛒 Add to Cart
                    </button>
                  )}
                  
                  {isBorrowedByMe(book) ? (
                    <button className="btn-return" onClick={() => handleReturn(book._id)}>Return</button>
                  ) : book.availableCopies > 0 ? (
                    <button className="btn-borrow" onClick={() => handleBorrow(book._id)}>Borrow</button>
                  ) : null}
                  
                  {member.memberId && member.memberId.startsWith('ADM') && (
                    <button className="btn-delete" onClick={() => handleDelete(book._id)}>Delete</button>
                  )}
                </div>

                {member.membershipType === 'guest' && (
                  <div style={{marginTop:'1rem',padding:'0.5rem',background:'rgba(255,193,7,0.1)',borderRadius:'8px',fontSize:'0.85rem',color:'#f39c12',textAlign:'center'}}>
                    Upgrade to buy books!
                  </div>
                )}
              </div>
            ))}
          </div>
        )}

        {!loading && filteredBooks.length === 0 && (
          <p style={{textAlign:'center',padding:'3rem'}}>No books found.</p>
        )}
      </div>
    </div>
  );
}

export default Books;
