import React from 'react';
import { Link } from 'react-router-dom';

function Home() {
  return (
    <div>
      <div className="hero">
        <h1>Welcome to Bookholics Store 2</h1>
        <p>Discover thousands of books and expand your knowledge</p>
        <div className="hero-buttons">
          <Link to="/books" className="btn btn-large">Browse Books</Link>
          <Link to="/memberships" className="btn btn-outline">View Memberships</Link>
        </div>
      </div>

      <div className="container">
        <div className="stats-section">
          <div className="stats-grid">
            <div className="stat-card">
              <div className="stat-number">5000+</div>
              <div className="stat-label">Books Available</div>
            </div>
            <div className="stat-card">
              <div className="stat-number">1200+</div>
              <div className="stat-label">Active Members</div>
            </div>
            <div className="stat-card">
              <div className="stat-number">50+</div>
              <div className="stat-label">Categories</div>
            </div>
            <div className="stat-card">
              <div className="stat-number">24/7</div>
              <div className="stat-label">Online Access</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default Home;
