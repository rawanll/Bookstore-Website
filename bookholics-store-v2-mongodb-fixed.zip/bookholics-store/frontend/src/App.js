import React, { useState, useEffect } from 'react';
import { BrowserRouter as Router, Routes, Route, Link, Navigate } from 'react-router-dom';
import Home from './pages/Home';
import Books from './pages/Books';
import MyAccount from './pages/MyAccount';
import AddBook from './pages/AddBook';
import Login from './pages/Login';
import Register from './pages/Register';
import Memberships from './pages/Memberships';
import ShoppingCart from './pages/ShoppingCart';
import './App.css';

function App() {
  const [member, setMember] = useState(null);

  useEffect(() => {
    const token = localStorage.getItem('token');
    const memberData = localStorage.getItem('member');
    if (token && memberData) {
      setMember(JSON.parse(memberData));
    }
  }, []);

  const logout = () => {
    localStorage.removeItem('token');
    localStorage.removeItem('member');
    setMember(null);
  };

  return (
    <Router>
      <div className="App">
        <nav className="navbar">
          <div className="container">
            <div className="nav-brand">
              <span className="logo">📚</span>
              <span className="brand-name">Bookholics Store 2</span>
            </div>
            
            <div className="nav-menu">
              {member ? (
                <>
                  <Link to="/" className="nav-link">Home</Link>
                  <Link to="/books" className="nav-link">Browse Books</Link>
                  {member.membershipType !== 'guest' && (
                    <Link to="/cart" className="nav-link">🛒 Cart</Link>
                  )}
                  <Link to="/memberships" className="nav-link">Memberships</Link>
                  <Link to="/account" className="nav-link">My Account</Link>
                  {member.memberId && member.memberId.startsWith('ADM') && (
                    <Link to="/add-book" className="nav-link">Add Book</Link>
                  )}
                  <div className="user-info">
                    <span className="member-badge">{member.memberId}</span>
                    <span className="member-name">{member.name}</span>
                  </div>
                  <button onClick={logout} className="btn-logout">Logout</button>
                </>
              ) : (
                <>
                  <Link to="/" className="nav-link">Home</Link>
                  <Link to="/login" className="btn-primary">Login</Link>
                  <Link to="/register" className="btn-secondary">Register</Link>
                </>
              )}
            </div>
          </div>
        </nav>

        <div className="main-content">
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/books" element={member ? <Books member={member} /> : <Navigate to="/login" />} />
            <Route path="/cart" element={member && member.membershipType !== 'guest' ? <ShoppingCart member={member} /> : <Navigate to="/memberships" />} />
            <Route path="/account" element={member ? <MyAccount member={member} setMember={setMember} /> : <Navigate to="/login" />} />
            <Route path="/memberships" element={member ? <Memberships member={member} setMember={setMember} /> : <Navigate to="/login" />} />
            <Route path="/add-book" element={member && member.memberId?.startsWith('ADM') ? <AddBook /> : <Navigate to="/" />} />
            <Route path="/login" element={!member ? <Login setMember={setMember} /> : <Navigate to="/" />} />
            <Route path="/register" element={!member ? <Register setMember={setMember} /> : <Navigate to="/" />} />
          </Routes>
        </div>

        <footer className="footer">
          <div className="container">
            <p>&copy; 2024 Bookholics Store 2. All rights reserved.</p>
            <p>Buy books, borrow books, build your reading journey</p>
          </div>
        </footer>
      </div>
    </Router>
  );
}

export default App;
