# Changelog - Bookholics Store 2

## Version 2.0.0 - Proxy Fix & Enhancements

### 🔧 Major Fixes

#### Proxy Configuration Issue (RESOLVED)
**Problem**: Application was crashing due to proxy misconfiguration in React app
**Solution**: 
- Removed `"proxy": "http://localhost:5000"` from `frontend/package.json`
- Created centralized API configuration system
- Updated all API calls to use full URLs

### ✨ New Features

1. **API Configuration System**
   - Created `/frontend/src/config/api.js` for centralized API URL management
   - Supports environment-specific configuration via `.env` file
   - Easier deployment to different environments

2. **Environment Configuration**
   - Added `.env` files for both frontend and backend
   - Added `.env.example` files with documentation
   - Support for custom API URLs and CORS origins

3. **Improved CORS Handling**
   - Updated backend CORS configuration
   - Support for credentials
   - Configurable allowed origins

### 📝 Changes Made

#### Frontend Changes
1. **Removed**: Proxy configuration from `package.json`
2. **Added**: 
   - `src/config/api.js` - API configuration module
   - `.env` - Environment variables
   - `.env.example` - Environment template
3. **Updated**: All page components to use `API_BASE_URL`
   - Login.js
   - Register.js
   - Books.js
   - AddBook.js
   - MyAccount.js
   - Memberships.js
   - ShoppingCart.js

#### Backend Changes
1. **Updated**: CORS configuration in `server.js`
   - Added corsOptions object
   - Support for environment-specific frontend URLs
   - Enabled credentials support

#### Branding Updates
1. Changed "Bookholics Store" to "Bookholics Store 2" throughout the app:
   - Navigation bar brand name
   - Footer text
   - Home page hero section
   - README title

### 📂 New Files
- `/frontend/src/config/api.js` - API configuration
- `/frontend/.env` - Frontend environment variables
- `/frontend/.env.example` - Frontend environment template
- `/setup.sh` - Quick setup script
- `/CHANGELOG.md` - This file
- `/README.md` - Updated with comprehensive instructions

### 🐛 Bug Fixes
- Fixed proxy-related crashes
- Fixed CORS errors during API calls
- Improved error handling in API requests

### 🚀 Deployment Improvements
- Easier configuration for different environments
- Clear separation between development and production settings
- Better documentation for deployment process

### 📖 Documentation
- Comprehensive README with setup instructions
- Troubleshooting section added
- Clear deployment configuration guide
- Quick start script for easy setup

### 🔄 Migration from Version 1

To migrate from the old version:
1. Pull the new code
2. Delete `node_modules` in both frontend and backend
3. Run `./setup.sh` or manually install dependencies
4. Create/update `.env` files as documented
5. Restart both servers

### ⚙️ Technical Details

**What Changed in API Calls:**
Before:
```javascript
await axios.post('/api/members/login', formData);
```

After:
```javascript
import API_BASE_URL from '../config/api';
await axios.post(`${API_BASE_URL}/api/members/login`, formData);
```

**Configuration:**
The API URL is now read from environment variable `REACT_APP_API_URL` with a fallback to `http://localhost:5000`.

### 🎯 Testing Checklist
- [x] Frontend builds successfully
- [x] Backend starts without errors
- [x] API calls work correctly
- [x] CORS errors resolved
- [x] Login/Register functionality works
- [x] Book browsing works
- [x] Shopping cart functions properly
- [x] Membership upgrades work
- [x] Admin book management works

### 📞 Support
If you encounter issues after upgrading:
1. Clear browser cache
2. Delete `node_modules` and reinstall
3. Verify `.env` files are configured correctly
4. Check that MongoDB is running
5. Ensure backend is running before starting frontend

---

**Release Date**: December 30, 2024
**Author**: Bookholics Store Development Team
**Version**: 2.0.0
